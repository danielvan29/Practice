create
    definer = root@`%` function test_data() returns int
begin
    declare num int default 1000000;
    declare i int default 0;
    while i<num do
         insert into app_user(`name`,`email`,`phone`,`gender`,`password`,`age`) values(concat('用户',i),'123@qq.com',concat('18',floor(rand()*((999999999-100000000)+100000000))),floor(rand()*2),uuid(),floor(rand()*100));
         set i = i+1;
    end while;
    return i;
end;

